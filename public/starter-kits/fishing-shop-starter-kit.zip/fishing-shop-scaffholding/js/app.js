const fishes = [
    {
        name: "clown-loach",
        size: 20,
        priceByKg: 8,
    },
    {
        name: "seahorse",
        size: 2,
        priceByKg: 3.5,
    },
    {
        name: "puffer-fish",
        size: 8,
        priceByKg: 6,
    },
    {
        name: "shrimp",
        size: 6,
        priceByKg: 14,
    },
];
